class VertexBrain:
    def synthesize(self, query, data):
        response = f"--- VERTEX INTELLIGENCE REPORT ---\nQuery: {query}\n"
        
        if not data:
            return "Vertex AI: No se han podido extraer datos de las 20 fuentes. Operando en modo offline."

        if "crypto" in data and data["crypto"]:
            # Manejo de estructura diferente entre CoinGecko y Binance
            val = data["crypto"].get("bitcoin", {}).get("usd") or data["crypto"].get("price")
            response += f"[Sector Finanzas]: BTC está a ${val}\n"

        if "weather" in data and data["weather"]:
            temp = data["weather"].get("current_weather", {}).get("temperature") or data["weather"].get("current_condition", [{}])[0].get("temp_C")
            response += f"[Sector Clima]: Temperatura actual: {temp}°C\n"

        response += "\n[Sistemas: 20 APIs en línea | Nivel de Confianza: Máximo]"
        return response

import json
import os

class VertexMemory:
    def __init__(self, file_path="user_memory.json"):
        self.file_path = file_path
        if not os.path.exists(self.file_path):
            with open(self.file_path, 'w') as f:
                json.dump({"user_name": "User", "preferences": {}}, f)

    def get_user_data(self):
        with open(self.file_path, 'r') as f:
            return json.load(f)

    def save_user_name(self, name):
        data = self.get_user_data()
        data["user_name"] = name
        with open(self.file_path, 'w') as f:
            json.dump(data, f)
        return f"Vertex: Memoria actualizada. Hola, {name}."

    def get_greeting(self):
        data = self.get_user_data()
        return f"Sistema Vertex listo. Saludos, {data['user_name']}."

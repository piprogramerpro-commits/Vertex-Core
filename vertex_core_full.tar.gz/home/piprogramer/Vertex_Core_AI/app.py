from flask import Flask, render_template, request, jsonify
from modules.api_hub import APIHub
from modules.ia_brain import VertexBrain
from modules.memory import VertexMemory

app = Flask(__name__)
hub = APIHub()
brain = VertexBrain()
mem = VertexMemory()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    user_input = request.json.get("query")
    
    # Lógica de memoria: Si el usuario dice "me llamo X"
    if "me llamo" in user_input.lower():
        name = user_input.lower().split("me llamo")[-1].strip()
        response = mem.save_user_name(name)
        return jsonify({"vertex_response": response})

    a_data = hub.get_context(user_input)
    final_text = brain.synthesize(user_input, a_data)
    
    # Añadir saludo personalizado si ya conocemos el nombre
    user_name = mem.get_user_data()["user_name"]
    final_text = f"[{user_name}]: " + final_text
    
    return jsonify({"vertex_response": final_text})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
